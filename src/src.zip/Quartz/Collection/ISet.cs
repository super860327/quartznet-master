using System.Collections.Generic;

namespace Quartz.Collection
{
    public interface ISet<T> : ICollection<T>
	{
	}
}